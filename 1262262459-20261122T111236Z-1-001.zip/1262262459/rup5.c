#include <stdio.h>
int main() {
int rows,cols;
//input the number of row and columns
printf("Enter the number of row:");
scanf("%d",&rows);
printf("Enter the number of columns:");
scanf("%d",&cols);
int mat1[rows][cols],mat2[rows][cols],result[rows][cols];
//input elements of the first matrix
printf("Enter element of the first matrix:\n");
for (int i = 0; i < rows;i++){
for (int j =0; j < cols;j++){
printf("Element [%d][%d]:", i,j);
scanf("%d",&mat1[i][j]);
}
}
//input elements of the second matrix
printf("\nenter element of the second matrix:\n");
for (int i=0;i < rows;i++){
for (int j =0; j < cols;j++){
printf("Element [%d][%d]:", i,j);
scanf("%d",&mat2[i][j]);
}
}//performing matrix addition
for (int i =0;i < rows;i++){
for (int j=0;j < cols;j++){
printf("%d\t",result[i][j]);
}
printf("\n");
}
return 0;
}
