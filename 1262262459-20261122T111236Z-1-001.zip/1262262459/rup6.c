#include<stdio.h>
int main() 
{
int A[2][2], B[2][2], C[2][2];
int i,j;
//input first matrix
printf("enter the measurements for first biological sample:\n");
for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
{
scanf("%d",&A[i][j]);
}
}
//input second matrix 
printf("enter the measurements for second biological sample:\n");
for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
{
scanf("%d",&B[i][j]);
}
}
//add the two matrices 
for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
{
C[i][j]=A[i][j]+B[i][j];
}
}
//display resultant matrix
printf("\nresultant measurement matrix:\n");
for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
{
printf("%d\t",C[i][j]);
}
printf("\n");
}
return 0;
}
